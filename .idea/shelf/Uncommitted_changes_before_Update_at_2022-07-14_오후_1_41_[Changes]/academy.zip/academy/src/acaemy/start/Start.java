package acaemy.start;

import academy.controller.AcademyController;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AcademyController ac = new AcademyController();
		ac.main();
	}

}
