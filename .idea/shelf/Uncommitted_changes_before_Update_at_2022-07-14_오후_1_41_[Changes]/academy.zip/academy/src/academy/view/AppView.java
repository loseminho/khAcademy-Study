package academy.view;

public class AppView {

}
