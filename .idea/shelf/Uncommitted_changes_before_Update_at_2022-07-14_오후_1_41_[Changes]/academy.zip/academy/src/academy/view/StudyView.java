package academy.view;

import java.util.Scanner;

import academy.vo.App;
import academy.vo.Pupil;
import academy.vo.Study;

public class StudyView {

	Scanner sc = new Scanner(System.in);

	public StudyView() {
		super();
		sc = new Scanner(System.in);
	}

	// 맨처음 메인 메뉴
	public int showMenu() {
		System.out.println("\n===== 학원 프로그램 =====\n");
		System.out.println("1. 학생");
		System.out.println("2. 강사");
		System.out.println("3. 학원");
		System.out.println("0. 프로그램 종료");
		System.out.print("선택 >>> ");
		return sc.nextInt();
	}

	// 수업 메인 메뉴
	public int stMenu() {
		System.out.println("==========================");
		System.out.println("\t 수업 관리");
		System.out.println("==========================");
		System.out.println("1. 신규 수업 추가");
		System.out.println("2. 전체 수업 조회");
		System.out.println("3. 기존 수업 수정");
		System.out.println("4. 기존 수업 삭제");
		System.out.println("5. 전체 학생 조회");
		System.out.println("6. 전체 강사 조회");
		System.out.println("7. 수강신청 명단 조회");
		System.out.println("0. 처음으로 돌아가기");
		System.out.print("선택 >>> ");
		return sc.nextInt();
	}

	// 수업 세부 메뉴
	// 1. 수업 추가
	public Study insertStudy() {
		System.out.println("==========================");
		System.out.println("\t신규 수업  추가");
		System.out.println("==========================");
		System.out.println("- 수업 추가 시 주의사항");
		System.out.println("1. 수업명은 5글자 이하, 띄어쓰기 불가");
		System.out.println("2. 수업요일은 월요일 ~ 금요일로 입력[월,화,수...]");
		System.out.println("3. 수업시간은 09 ~ 22시 사이 숫자 입력");
		System.out.println();
		System.out.print("수업명 : ");
		String stName = sc.next();
		System.out.print("수업요일 : ");
		char stDay = sc.next().charAt(0);
		System.out.print("수업시간 : ");
		int stTime = sc.nextInt();
		System.out.print("수강인원 : ");
		int stNum = sc.nextInt();
		System.out.print("수당[단위=만원] : ");
		int stPrice = sc.nextInt();
		
		Study st = new Study(stName, stDay, stTime, stNum,stPrice);
		return st;
	} // insertStudy 메서드 끝

	// 2. 모든 수업 출력
	public void printAllStudys(Study[] studys, int stIndex) {
		System.out.println("==========================");
		System.out.println("\t전체 수업  조회");
		System.out.println("==========================");
		if (stIndex == 0) {
			System.out.println("등록된 수업이 없습니다.");
		} else {
			System.out.println("No.\t수업명\t수업요일\t수업시간\t수강인원");
			System.out.println("==========================================");
			for (int i = 0; i < stIndex; i++) {
				Study st = studys[i];
				System.out.printf("%d\t%s\t%c\t%d시\t%d%n", i + 1, st.getStName(), st.getStDay(), st.getStTime(),
						st.getStNum());
			}
		}
	} // printAllStudys 메서드 끝

	// 3. 수업 수정
	// 수업 수정할 내용 입력받아 새로운 수업 객체를 만들고,
	// 그 주소를 기존 객체의 인덱스 값에 넣을 수 있게 반환
	public Study updateStudy() {
		System.out.println("==========================");
		System.out.println("\t기존 수업  수정");
		System.out.println("==========================");
		System.out.println("- 수업 수정 시 주의사항");
		System.out.println("1. 수업명은 5글자 이하, 띄어쓰기 불가");
		System.out.println("2. 수업요일은 월요일 ~ 금요일로 입력");
		System.out.println("3. 수업시간은 09 ~ 22시 사이로 숫자만 입력");
		System.out.println();
		System.out.print("수업명 : ");
		String stName = sc.next();
		System.out.print("수업요일 : ");
		char stDay = sc.next().charAt(0);
		System.out.print("수업시간 : ");
		int stTime = sc.nextInt();
		System.out.print("수강인원 : ");
		int stNum = sc.nextInt();
		System.out.println("수당 : ");
		int stPrice = sc.nextInt();

		Study st = new Study(stName, stDay, stTime, stNum, stPrice);
		return st;
	} // updateStudy 메서드 끝

	// 4. 모든 학생 출력
	public void printAllPupils(Pupil[] pupils, int puIndex) {
		System.out.println("==========================");
		System.out.println("\t 전체 학생  조회");
		if (puIndex == 0) {
			System.out.println("등록된 학생이 없습니다.");
		} else {
			System.out.println("이름\t나이\t주소\t성별");
			System.out.println("==========================================");
			for (int i = 0; i < puIndex; i++) {
				Pupil pu = pupils[i];
				System.out.printf("%s\t%d\t%s\t%s%n", pu.getPuName(), pu.getPuAge(), pu.getPuAddr(), pu.getPuGender());
			}
		}
	}

	// 6. 모든 수강신청 출력
	public void printAllApp(App[] apps, int apIndex) {
		System.out.println("==========================");
		System.out.println("\t전체 수강신청  조회");
		if (apIndex == 0) {
			System.out.println("등록된 수강신청이 없습니다.");
		} else {
			System.out.println("학생명\t수업명\t수업요일\t수업시간\t수강인원\t수당");
			System.out.println("==========================================");
			for (int i = 0; i < apIndex; i++) {
				App ap = apps[i];
				System.out.printf("%s\t%s\t%c\t%d\t%d\t%d%n", ap.getApPuName(), ap.getApStName(), ap.getApDay(),
						ap.getApTime(), ap.getApNum(),ap.getApPrice());
			}
		}
	}

	// 기타 메서드들
	// 1. 수업명을 입력받아 반환하는 메서드
	public String getStName(String str) {
		System.out.println("==========================");
		System.out.println("\t기존 수업 " + str);
		System.out.print(str + "할 수업명 : ");
		return sc.next();
	}

	// 2. 완료 멘트
	public void stSuccess(String str) {
		System.out.println("==========================");
		System.out.println("수업 " + str + " 완료.");
		System.out.println("==========================");
	}

	// 3. 추가되지 않은 수업명을 입력했을 때 뜨는 멘트
	public void noSearchStudy() {
		System.out.println("==========================");
		System.out.println("등록되지 않은 수업입니다.");
		System.out.println("==========================");
	}
}