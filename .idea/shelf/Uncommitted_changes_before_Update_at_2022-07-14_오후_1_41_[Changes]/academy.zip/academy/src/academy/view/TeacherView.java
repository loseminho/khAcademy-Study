package academy.view;

import java.util.Scanner;

import academy.vo.Pupil;
import academy.vo.Study;
import academy.vo.Teacher;

public class TeacherView {

	Scanner sc = new Scanner(System.in);

	public int showMenu() {
		System.out.println("\n===== 학원 프로그램 ======\n");
		System.out.println("1. 학생 관리 (관리자용)");
		System.out.println("2. 수업 관리 (관리자용)");
		System.out.println("3. 신청 관리 (학생용)");
		System.out.println("0. 프로그램 종료");
		System.out.print("선택 >>> ");
		return sc.nextInt();
	}

	public int tcMenu() {
		System.out.println("==========================");
		System.out.println("\t강      사");
		System.out.println("==========================");
		System.out.println("1. 강사 정보 등록");
		System.out.println("2. 강사 정보 수정");
		System.out.println("3. 강사 정보 삭제");
		System.out.println("4. 학생 목록 출력");
		System.out.println("5. 강사 목록 출력");
		System.out.println("6. 강사 등급 확인");
		System.out.println("7. 강의 신청하기(강사용)");
		System.out.println("0. 초기 화면으로");
		System.out.print("선택 >>> ");
		int tcsel = sc.nextInt();
		return tcsel;
	}

	public Teacher updateTeacher() {
		Teacher t = new Teacher();
		System.out.print("- 수정할 이름 입력 :");
		String updatename = sc.next();
		t.setTcName(updatename);
		System.out.print("- 수정할 나이 입력 :");
		int updateAge = sc.nextInt();
		t.setTcAge(updateAge);
		System.out.print("- 수정할 주소 입력 :");
		String updateAddr = sc.next();
		t.setTcAddr(updateAddr);
		System.out.print("- 수정할 성별 입력 :");
		String updateGender = sc.next();
		t.setTcGender(updateGender);
		return t;

	}

	public void updateSuccess() {
		System.out.println("==========================");
		System.out.println("\t수정이 완료되었습니다! \t");
		System.out.println("==========================");
	}

	public Teacher insertTeacher() {
		System.out.print("- 이름 입력 : ");
		String name = sc.next();
		System.out.print("- 나이 입력 : ");
		int age = sc.nextInt();
		System.out.print("- 주소 입력 : ");
		String addr = sc.next();
		System.out.print("- 성별 입력 [남/여] : ");
		String gender = sc.next();
		Teacher t = new Teacher(name, age, addr, gender);
		return t;
	}

	public void printAllPupil(Pupil[] pupil, int puIdex) {
		System.out.println("이름\t나이\t주소\t성별");
		System.out.println("==========================");
		for (int i = 0; i < puIdex; i++) {
			Pupil p = pupil[i];
			System.out.printf("%s\t%d\t%s\t%s", p.getPuName(), p.getPuAge(), p.getPuAddr(), p.getPuGender());
			System.out.println();
		}
	}

	public String getName(String str) {
		System.out.print("- " + str + "할 이름 입력 : ");
		String name = sc.next();
		return name;
	}

	public void deleteSuccess() {
		System.out.println("==========================");
		System.out.println("삭제가 완료 되었습니다.");
		System.out.println("==========================");
	}

	public void noSearch() {
		System.out.println("==========================");
		System.out.println("정보를 찾을 수 없습니다.");
		System.out.println("==========================");
	}

	public void insertSuccess() {
		System.out.println("등록이 완료되었습니다!");
	}

	public void line(String str) {
		System.out.println("==========================");
		System.out.println("\t" + str + "\t");
		System.out.println("==========================");
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void printAllTeacher(Teacher[] teachers, int tcIndex) {
		System.out.println("이름\t나이\t주소\t성별");
		System.out.println("==========================");
		for (int i = 0; i < tcIndex; i++) {
			Teacher t = teachers[i];
			System.out.printf("%s\t%d\t%s\t%s", t.getTcName(), t.getTcAge(), t.getTcAddr(), t.getTcGender());
			System.out.println();
		}
	}
	public String printTeacherGradeName() {
		System.out.println("==========================");
		System.out.println("\t강사 등급  조회");
		System.out.println("==========================");
		System.out.println("등급 확인할 강사 이름 입력 :");
		String GradeName = sc.next();
		return GradeName;
	}
	
	public void printTeacherGrade(Teacher[] teachers, int searchTcIndex) {
		System.out.println("╔═══━━━─── • ───━━━═══╗");
		System.out.println("강사님의 등급은 : ");
		Teacher t = teachers[searchTcIndex];
		System.out.println("현재 포인트 : "+teachers[searchTcIndex].getTcPrice());
		if(teachers[searchTcIndex].getTcPrice()>1000) {
			System.out.print("╔TOP강사╝");
		}else if(teachers[searchTcIndex].getTcPrice()>700) {
			System.out.print("╔Gold강사╝");
		}else if(teachers[searchTcIndex].getTcPrice()>400) {
			System.out.print("╔Silver강사╝");
		}else {
			System.out.print("╔비기너강사╝");
		}
		System.out.println(" 입니다!");
		System.out.println("╚═══━━━─── • ───━━━═══╝");
	}
	public String choiceStudyName(){
		System.out.println("선택하실 선생님의 이름을 입력하세요 : ");
		String name = sc.next();
		return name;
	}
	public void printAllStudy(Study[] studys,int stIndex) {
		System.out.println("===================================");
		System.out.println("\t강의  목록   출력");
		System.out.println("===================================");
		System.out.println("수업명\t수업요일\t수업시간\t수강인원\t수당");
		System.out.println("===================================");
		for(int i=0; i<stIndex;i++) {
			System.out.printf("%s\t%c\t%d\t%d\t%d\n",
			studys[i].getStName()
			,studys[i].getStDay()
			,studys[i].getStTime()
			,studys[i].getStNum()
			,studys[i].getStPrice());
		}
	}
}