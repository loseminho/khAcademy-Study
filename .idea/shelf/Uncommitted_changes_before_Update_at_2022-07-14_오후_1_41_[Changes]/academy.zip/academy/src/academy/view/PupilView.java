package academy.view;
import java.util.Scanner;

import academy.vo.App;
import academy.vo.Pupil;
import academy.vo.Study;

public class PupilView {
	Scanner sc = new Scanner(System.in);
	
	public int puMenu() {
		System.out.println("==========================");
		System.out.println("\t학      생");
		System.out.println("==========================");
		System.out.println("1. 학생 정보 등록");
		System.out.println("2. 학생 정보 수정");
		System.out.println("3. 학생 정보 삭제");
		System.out.println("4. 강의 목록 출력");
		System.out.println("5. 수강 신청 등록");
		System.out.println("6. 수강 신청 목록 출력");
		System.out.println("0. 이전 화면으로");
		System.out.println("선택 >>>");
		int sel = sc.nextInt();
		return sel;
	}
	
	public Pupil insertPupil(String str) {
		System.out.println("학생 이름을 "+str+" 하세요 : ");
		String name = sc.next();
		System.out.println("학생 나이를 "+str+" 하세요 : ");
		int age = sc.nextInt();
		System.out.println("학생 주소를 "+str+" 하세요 : ");
		sc.nextLine();
		String addr = sc.nextLine();
		System.out.println("학생 성별을 "+str+" 하세요[남/여] : ");
		String gen = sc.next();
		return new Pupil(name,age,addr,gen);
	}
	public Pupil updatePupil(String str) {
		System.out.println("==========================");
		System.out.println("\t학생 정보  "+str);
		System.out.println("==========================");
		System.out.println(str+"할 학생 이름 : ");
		String name = sc.next();
		System.out.println("나이 "+str+" : ");
		int age = sc.nextInt();
		System.out.println("주소 "+str+" : ");
		sc.nextLine();
		String addr = sc.nextLine();
		System.out.println("성별 "+str+" [남/여] : ");
		String gen = sc.next();
		return new Pupil(name, age, addr, gen);
	}
	public void printAllStudy(Study[] studys,int stIndex) {
		System.out.println("===================================");
		System.out.println("\t강의  목록   출력");
		System.out.println("===================================");
		System.out.println("수업명\t수업요일\t수업시간\t수강인원");
		System.out.println("===================================");
		for(int i=0; i<stIndex;i++) {
			System.out.printf("%s\t%c\t%d\t%d\n",
			studys[i].getStName()
			,studys[i].getStDay()
			,studys[i].getStTime()
			,studys[i].getStNum());
		}
	}
	public String printAllStudy1() {
		System.out.println("==========================");
		System.out.println("\t수강  신청  하기 ");
		System.out.println("==========================");
		System.out.println("수강 신청 할 이름 입력 : ");
		String name = sc.next();
		return name;
	}
	public String printAllStudy2() {
		System.out.println("수강신청 할 과목명 입력 : ");
		String stName = sc.next();
		return stName;
	}
	public void printMyApp() {
		System.out.println("==========================");
		System.out.println("\t수강 신청  목록  보기");
		System.out.println("==========================");
		System.out.println("이름\t강의명\t총인원\t강의요일\t강의시간");
		System.out.println("---------------------------------");
	}
	public void printMyApps(App[] apps,int i) {
		System.out.printf("%s\t%s\t%d\t%s\t%d\n"
				,apps[i].getApPuName()
				,apps[i].getApStName()
				,apps[i].getApNum()
				,apps[i].getApDay()
				,apps[i].getApTime());
	}
	
	public String getPupilName(String str) {
		System.out.println("\n===== 학생 정보 "+str+" =====\n");
		System.out.println(str+"할 학생 이름을 입력 하세요 : ");
		String name = sc.next();
		return name;
	}
	public void puSuccess(String str) {
		System.out.println("==========================");
		System.out.println(str +"이 완료되었습니다!");
		System.out.println("==========================");
	}
	public void noSearch() {
		System.out.println("==========================");
		System.out.println("조회 되지 않습니다.");
		System.out.println("==========================");
	}
}
