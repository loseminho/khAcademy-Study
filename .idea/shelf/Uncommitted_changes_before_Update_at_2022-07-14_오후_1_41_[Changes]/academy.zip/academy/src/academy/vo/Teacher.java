package academy.vo;

public class Teacher {

	private String tcName;
	private int tcAge;
	private String tcAddr;
	private String tcGender;
	private int tcPrice;
	
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Teacher(String tcName, int tcAge, String tcAddr, String tcGender, int tcPrice) {
		super();
		this.tcName = tcName;
		this.tcAge = tcAge;
		this.tcAddr = tcAddr;
		this.tcGender = tcGender;
		this.tcPrice = tcPrice;
	}
	
	public Teacher(String tcName, int tcAge, String tcAddr, String tcGender) {
		super();
		this.tcName = tcName;
		this.tcAge = tcAge;
		this.tcAddr = tcAddr;
		this.tcGender = tcGender;
	}
	public String getTcName() {
		return tcName;
	}
	public void setTcName(String tcName) {
		this.tcName = tcName;
	}
	public int getTcAge() {
		return tcAge;
	}
	public void setTcAge(int tcAge) {
		this.tcAge = tcAge;
	}
	public String getTcAddr() {
		return tcAddr;
	}
	public void setTcAddr(String tcAddr) {
		this.tcAddr = tcAddr;
	}
	public String getTcGender() {
		return tcGender;
	}
	public void setTcGender(String tcGender) {
		this.tcGender = tcGender;
	}
	public int getTcPrice() {
		return tcPrice;
	}
	public void setTcPrice(int tcPrice) {
		this.tcPrice = tcPrice;
	}
	
}