package academy.vo;

public class Pupil {
	private String puName;
	private int puAge;
	private String puAddr;
	private String puGender;
	public Pupil() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Pupil(String puName, int puAge, String puAddr, String puGender) {
		super();
		this.puName = puName;
		this.puAge = puAge;
		this.puAddr = puAddr;
		this.puGender = puGender;
	}

	public String getPuName() {
		return puName;
	}
	public void setPuName(String puName) {
		this.puName = puName;
	}
	public int getPuAge() {
		return puAge;
	}
	public void setPuAge(int puAge) {
		this.puAge = puAge;
	}
	public String getPuAddr() {
		return puAddr;
	}
	public void setPuAddr(String puAddr) {
		this.puAddr = puAddr;
	}
	public String getPuGender() {
		return puGender;
	}
	public void setPuGender(String puGender) {
		this.puGender = puGender;
	}
	
	
}
