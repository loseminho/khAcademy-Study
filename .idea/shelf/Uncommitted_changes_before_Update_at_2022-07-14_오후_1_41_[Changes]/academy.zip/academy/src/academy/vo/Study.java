package academy.vo;

public class Study {
	private String stName;
	private char stDay;
	private int stTime;
	private int stNum;
	private int stPrice;
	public Study() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Study(String stName, char stDay, int stTime, int stNum, int stPrice) {
		super();
		this.stName = stName;
		this.stDay = stDay;
		this.stTime = stTime;
		this.stNum = stNum;
		this.stPrice = stPrice;
	}

	public Study(String stName, char stDay, int stTime, int stNum) {
		super();
		this.stName = stName;
		this.stDay = stDay;
		this.stTime = stTime;
		this.stNum = stNum;
	}

	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public char getStDay() {
		return stDay;
	}
	public void setStDay(char stDay) {
		this.stDay = stDay;
	}
	public int getStTime() {
		return stTime;
	}
	public void setStTime(int stTime) {
		this.stTime = stTime;
	}
	public int getStNum() {
		return stNum;
	}
	public void setStNum(int stNum) {
		this.stNum = stNum;
	}
	public int getStPrice() {
		return stPrice;
	}
	public void setStPrice(int stPrice) {
		this.stPrice = stPrice;
	}
	
}
