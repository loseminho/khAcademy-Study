package academy.vo;

public class App {
	private String apPuName;
	private String apStName;
	private int apNum;
	private char apDay;
	private int apTime;
	private int apPrice;
	public App(String apPuName, String apStName, int apNum, char apDay, int apTime, int apPrice) {
		super();
		this.apPuName = apPuName;
		this.apStName = apStName;
		this.apNum = apNum;
		this.apDay = apDay;
		this.apTime = apTime;
		this.apPrice = apPrice;
	}
	public App(String apPuName, String apStName, int apNum, char apDay, int apTime) {
		super();
		this.apPuName = apPuName;
		this.apStName = apStName;
		this.apNum = apNum;
		this.apDay = apDay;
		this.apTime = apTime;
	}
	public App() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getApPuName() {
		return apPuName;
	}
	public void setApPuName(String apPuName) {
		this.apPuName = apPuName;
	}
	public String getApStName() {
		return apStName;
	}
	public void setApStName(String apStName) {
		this.apStName = apStName;
	}
	public int getApNum() {
		return apNum;
	}
	public void setApNum(int apNum) {
		this.apNum = apNum;
	}
	public char getApDay() {
		return apDay;
	}
	public void setApDay(char apDay) {
		this.apDay = apDay;
	}
	public int getApTime() {
		return apTime;
	}
	public void setApTime(int apTime) {
		this.apTime = apTime;
	}
	public int getApPrice() {
		return apPrice;
	}
	public void setApPrice(int apPrice) {
		this.apPrice = apPrice;
	}


}
