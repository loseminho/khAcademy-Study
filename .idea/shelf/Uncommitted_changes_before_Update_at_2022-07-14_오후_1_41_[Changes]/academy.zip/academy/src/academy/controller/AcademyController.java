package academy.controller;

import academy.vo.*;
import academy.view.*;

public class AcademyController {
	// 학생
	private Pupil[] pupils;
	private int puIndex;
	private String puName;
	private int puAge;
	private String puAddr;
	private String puGender;
	private PupilView puView;

	// 강사
	private Teacher[] teachers;
	private int tcIndex;
	private String tcName;
	private int tcAge;
	private String tcAddr;
	private String tcGender;
	private int tcPrice;
	private TeacherView tcView;

	// 학원
	private Study[] studys;
	private int stIndex;
	private String stName;
	private char stDay;
	private int stTime;
	private int stNum;
	private int stPrice;
	private StudyView stView;

	// 수강신청
	private App[] apps;
	private int apIndex;
	private String apPuName;
	private String apStName;
	private int apNum;
	private char apDay;
	private int apTime;
	private AppView apView;

	public AcademyController() {
		pupils = new Pupil[30];
		puIndex = 0;
		puView = new PupilView();
		teachers = new Teacher[30];
		tcIndex = 0;
		tcPrice = 0;
		tcView = new TeacherView();
		studys = new Study[30];
		stIndex = 0;
		stView = new StudyView();
		apps = new App[30];
		apIndex = 0;
		apView = new AppView();
	}

	public void main() {
		while (true) {
			int sel = stView.showMenu();

			switch (sel) {
			case 1:
				// 학생
				puMain();
				break;
			case 2:
				// 강사
				tcMain();
				break;
			case 3:
				// 학원
				stMain();
				break;
			case 0:
				System.out.println("프로그램을 종료합니다.");
				return;
			default:
				System.out.println("잘못 입력하셨습니다.");
				break;
			}
		} // 무한반복문 끝
	} // main 메서드 끝

	// pu 학생
	public void puMain() {
		while (true) {
			int sel = puView.puMenu();
			switch (sel) {
			case 1:// 학생 정보 등록
				insertPupil();
				break;
			case 2:// 학생 정보 수정
				updatePupil();
				break;
			case 3:// 학생 정보 삭제
				deletePupil();
				break;
			case 4:// 강의 목록 출력
				printAllStudy();
				break;
			case 5:// 수강 신청 등록
				pupilInsertStudy();
				break;
			case 6:// 수강 신청 목록 출력
				printAllMyApps();
				break;
			case 0:// 이전 화면으로
				main();
				return;
			}
		}
	}

	public void insertPupil() {
		Pupil p = puView.insertPupil("등록");
		pupils[puIndex++] = p;
		puView.puSuccess("가입");
	}

	public void updatePupil() {
		String name = puView.getPupilName("수정");
		int searchPuIndex = searchPuName(name);
		if (searchPuIndex == -1) {
			puView.noSearch();
		} else {
			Pupil p = puView.updatePupil("수정");
			pupils[searchPuIndex] = p;
			puView.puSuccess("수정");
		}
	}

	public void deletePupil() {
		String name = puView.getPupilName("삭제");
		int searchPuIndex = searchPuName(name);
		if (searchPuIndex == -1) {
			puView.noSearch();
		} else {
			for (int i = searchPuIndex; i < puIndex - 1; i++) {
				pupils[i] = pupils[i + 1];
			}
			puIndex--;
			puView.puSuccess("삭제");
		}
	}

	public void printAllStudy() {
		puView.printAllStudy(studys, stIndex);
	}

	public void pupilInsertStudy() {
		String name = puView.printAllStudy1();
		int searchPuIndex = searchPuName(name);
		if (searchPuIndex == -1) {
			puView.noSearch();
		} else {
			puView.printAllStudy(studys, stIndex);
			String stName = puView.printAllStudy2();
			int searchStIndex = searchStNames(stName);
			if (searchStIndex == -1) {
				puView.noSearch();
			} else {
				Study s = studys[searchStIndex];
				App a = new App(name, studys[searchStIndex].getStName(), studys[searchStIndex].getStNum(),
						studys[searchStIndex].getStDay(), studys[searchStIndex].getStTime());
				apps[apIndex++] = a;
				puView.puSuccess("수강신청");
			}
		}
	}

	public void printAllMyApps() {
		String name = puView.getPupilName("수강신청 확인");
		puView.printMyApp();
		for (int i = 0; i < apIndex; i++) {
			if (name.equals(apps[i].getApPuName())) {
				puView.printMyApps(apps, i);
			}
		}
	}

	public int searchPuName(String name) {
		for (int i = 0; i < puIndex; i++) {
			Pupil p = pupils[i];
			if (name.equals(p.getPuName())) {
				return i;
			}
		}
		return -1;
	}

	public int searchStNames(String stName) {
		for (int i = 0; i < stIndex; i++) {
			Study p = studys[i];
			if (stName.equals(p.getStName())) {
				return i;
			}
		}
		return -1;
	}

	// st학원
	public void stMain() {
		while (true) {
			int sel = stView.stMenu();

			switch (sel) {
			case 1:
				insertStudy();
				break;
			case 2:
				printAllStudys();
				break;
			case 3:
				updateStudy();
				break;
			case 4:
				deleteStudy();
				break;
			case 5:
				printAllPupil();
				break;
			case 6:
				printAllTeacher();
				break;
			case 0:
				System.out.println("처음으로 돌아갑니다.");
				return;
			default:
				System.out.println("잘못 입력하셨습니다.");
				break;
			}
		}
	} // 수업 메뉴 메서드 끝

	// 수업 세부 메뉴
	public void insertStudy() {
		studys[stIndex++] = stView.insertStudy();
		stView.stSuccess("추가");
	}

	public void printAllStudys() {
		stView.printAllStudys(studys, stIndex);
	}
	

	public void updateStudy() {
		String stName = stView.getStName("수정");
		int searchCode = searchStudy(stName);

		if (searchCode == -1) {
			stView.noSearchStudy();
		} else {
			studys[searchCode] = stView.updateStudy();
			stView.stSuccess("수정");
		}
	}

	public void deleteStudy() {
		String stName = stView.getStName("삭제");
		int searchCode = searchStudy(stName);

		if (searchCode == -1) {
			stView.noSearchStudy();
		} else {
			for (int i = searchCode; i < stIndex - 1; i++) {
				studys[i] = studys[i + 1];
			}
			stIndex--;
			stView.stSuccess("삭제");
		}
	}

	// 입력받은 강의명이 강의 배열의 몇 번 인덱스에 있는지 찾기
	public int searchStudy(String stName) {
		for (int i = 0; i < stIndex; i++) {
			Study st = studys[i];
			if (stName.equals(st.getStName())) {
				return i;
			}
		}
		return -1;
	}

	// tc 강사
	public void tcMain() {
		while (true) {
			int sel = tcView.tcMenu();
			switch (sel) {
			case 1://강사 정보 등록
				insertTeacher();
				break;
			case 2://강사 정보 수정
				updateTeacher();
				break;
			case 3://강사 정보 삭제
				deleteTeacher();
				break;
			case 4://학생 목록 출력
				printAllPupil();
				break;
			case 5://강사 목록 출력
				printAllTeacher(); // 확인용
				break;
			case 6://강사 등급 확인
				printTeacherGrade(); // 확인용
				break;	
			case 7://강의 신청하기(강사용)
				choiceStudy();
				break;
			case 0:
				main();
				return;
			}
		}
	}
	
	public void choiceStudy() {
		String name = tcView.choiceStudyName();//강사 이름 입력 저장
		int searchTcIndex = searchTcName(name);//강사 저장 배열 
		if (searchTcIndex == -1) {
			puView.noSearch();//조회 안됨
		} else {
			tcView.printAllStudy(studys, stIndex);//강의 전체 출력
			String stName = puView.printAllStudy2();//강의명 선택 저장
			int searchStIndex = searchStNames(stName);//강의 저장 배열 
			if (searchStIndex == -1) {
				puView.noSearch();
			} else {
				int num = studys[searchStIndex].getStPrice();
				Teacher t = teachers[searchTcIndex];
				t.setTcPrice(t.getTcPrice()+num);
			}
		}
	}
	
	public void printTeacherGrade() {
		String name = tcView.printTeacherGradeName();
		int searchTcIndex = searchTcName(name);
		if(searchTcIndex == -1) {
			puView.noSearch();
		}else {
			Teacher t = teachers[searchTcIndex];
			tcView.printTeacherGrade(teachers,searchTcIndex);
		}
	}
	public int searchTcName(String name) {
		for(int i=0; i<stIndex;i++) {
			Teacher t = teachers[i];
			if(name.equals(t.getTcName())) {
				return i;
			}
		}
		return -1;
	}
	
	
	public void printAllTeacher() {
		tcView.printAllTeacher(teachers, tcIndex);
	}

	public void updateTeacher() {
		tcView.line("강사 정보 수정");
		String name = tcView.getName("수정");
		int searchIndex = searchTIndex(name);
		if (searchIndex == -1) {
			tcView.noSearch();
		} else {
			Teacher t = tcView.insertTeacher();
			teachers[searchIndex] = t;
			tcView.updateSuccess();
		}
	}

	public void deleteTeacher() {
		String name = tcView.getName("삭제");
		int searchIndex = searchTIndex(name);
		if (searchIndex == -1) {
			tcView.noSearch();
		} else {
			for (int i = searchIndex; i < tcIndex - 1; i++) {
				teachers[i] = teachers[i - 1];
			}
			tcIndex--;
			tcView.deleteSuccess();
		}
	}

	public void printAllPupil() {
		tcView.line("전체 학생 조회");
		tcView.printAllPupil(pupils, puIndex);

	}

	public void insertTeacher() {
		tcView.line("강사 정보 등록");
		Teacher t = tcView.insertTeacher();
		teachers[tcIndex++] = t;
		tcView.insertSuccess();
	}

	public int searchTIndex(String name) {
		for (int i = 0; i < tcIndex; i++) {
			Teacher t = teachers[i];
			if (name.equals(t.getTcName()))
				return i;
		}
		return -1;
	}
}
